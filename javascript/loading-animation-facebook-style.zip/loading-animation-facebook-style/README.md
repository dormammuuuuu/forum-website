# Loading Animation Facebook Style

A Pen created on CodePen.io. Original URL: [https://codepen.io/brucevang/pen/qZOPwR](https://codepen.io/brucevang/pen/qZOPwR).

